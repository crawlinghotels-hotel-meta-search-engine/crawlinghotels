package com.example.demo.pojo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;

public class GenericClass  {

	
	public HashSet<Object> getByRating(List<expedia> exp,List<booking_com> book,List<fabhotels> fb)
	{
		
		HashSet<Object> hs=new HashSet<Object>();
		
		for(Object o:exp)
		{
			
			hs.add(o);
		}
		
		for(Object o:book)
		{
			hs.add(o);
			
		}
	
		for(Object o:fb)
		{
			hs.add(o);
			
		}
		
	
		

		return hs;
	}
	
}
