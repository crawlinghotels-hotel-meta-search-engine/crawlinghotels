package com.example.demo.controller;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.pojo.GenericClass;
import com.example.demo.pojo.booking_com;
import com.example.demo.pojo.expedia;
import com.example.demo.pojo.fabhotels;
import com.example.demo.repository.booking_comRepository;
import com.example.demo.repository.expediaRepository;
import com.example.demo.repository.fabhotelsRepository;




@RestController

public class HotelController  {
	
	
	
	@Autowired
	private expediaRepository expediar;
	@Autowired
	private booking_comRepository bookingr;
	@Autowired
	private fabhotelsRepository fabr;
	
	
	
	@GetMapping("/hello")
	public List<Object> getAllHotels()
	{
		
	List<Object> lobj=new ArrayList<Object>();
	lobj.add(expediar.findAll());
	lobj.add(bookingr.findAll());	
	lobj.add(fabr.findAll());
		return lobj;	
	}
	
	
	@GetMapping("/price")
	public HashSet<Object> getSortHotels()
	{
	
	List<expedia> exp=expediar.findAll(org.springframework.data.domain.Sort.by("price"));
	List<booking_com> book=bookingr.findAll(org.springframework.data.domain.Sort.by("price"));	
	List<fabhotels> fb=fabr.findAll(org.springframework.data.domain.Sort.by("price"));
	
	GenericClass gen=new GenericClass();
	
	return gen.getByRating(exp,book,fb);
	
	}
	
	

	
	
	
	
	
	

}
