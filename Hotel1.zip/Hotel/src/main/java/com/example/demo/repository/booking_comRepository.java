package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.pojo.booking_com;

public interface booking_comRepository extends JpaRepository<booking_com,String>  {

}
