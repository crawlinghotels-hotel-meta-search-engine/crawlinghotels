package com.example.demo.pojo;

public class HotelList {

	expedia ex;
	booking_com book;
	fabhotels fb;
	
	public HotelList(expedia ex, booking_com book, fabhotels fb) {
		super();
		this.ex = ex;
		this.book = book;
		this.fb = fb;
	}
	
	public expedia getEx() {
		return ex;
	}

	public void setEx(expedia ex) {
		this.ex = ex;
	}

	public booking_com getBook() {
		return book;
	}

	public void setBook(booking_com book) {
		this.book = book;
	}

	public fabhotels getFb() {
		return fb;
	}

	public void setFb(fabhotels fb) {
		this.fb = fb;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((book == null) ? 0 : book.hashCode());
		result = prime * result + ((ex == null) ? 0 : ex.hashCode());
		result = prime * result + ((fb == null) ? 0 : fb.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HotelList other = (HotelList) obj;
		if (book == null) {
			if (other.book != null)
				return false;
		} else if (!book.equals(other.book))
			return false;
		if (ex == null) {
			if (other.ex != null)
				return false;
		} else if (!ex.equals(other.ex))
			return false;
		if (fb == null) {
			if (other.fb != null)
				return false;
		} else if (!fb.equals(other.fb))
			return false;
		return true;
	}
	
	
}
