-- MySQL dump 10.13  Distrib 8.0.12, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: dbpune
-- ------------------------------------------------------
-- Server version	8.0.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `booking_com`
--

DROP TABLE IF EXISTS `booking_com`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `booking_com` (
  `hotel_name` varchar(45) NOT NULL,
  `city` varchar(45) NOT NULL,
  `address` varchar(255) NOT NULL,
  `star` int(11) NOT NULL,
  `rating` varchar(45) DEFAULT NULL,
  `price` double NOT NULL,
  `dist_airport` double NOT NULL,
  `dist_stat` double NOT NULL,
  `rooms` int(11) DEFAULT NULL,
  `checkIn` varchar(50) DEFAULT NULL,
  `chechOut` varchar(50) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`hotel_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_com`
--

LOCK TABLES `booking_com` WRITE;
/*!40000 ALTER TABLE `booking_com` DISABLE KEYS */;
INSERT INTO `booking_com` VALUES ('Conrad Pune','Pune','Conrad Pune, 7 Mangaldas Road, 411001, Pune.',5,'Excellent',11368,6.30,2.30,7,'2019-08-02','2019-08-10','conrad1'),('FabExpress Karishma','Pune','FabExpress Karishma 318, Rasta Peth, Near K.E.M. Hospital, 411011, Pune.',3,'Good',1594,9.70,2.30,8,'2019-08-02','2019-08-15','fab_karishma4'),('FabExpress Konark Inn Ghansoli','Mumbai','FabExpress Konark Inn Ghansoli ,Sector Number 4 Road, Plot No 351/352, 400701, Mumbai, India',3,'Averaga',1990,32,24.5,10,'2019-08-05','2019-08-15','Konark2'),('FabHotel Alpine Tree','Delhi','FabHotel Alpine Tree, A-65, National Highway - 08, Near IGI Airport, Mahipalpur, New Delhi 110037',3,'Average',1959,7.8,16.1,9,'2019-08-05','2019-08-15','fabAlpine2'),('FabHotel Galaxy Patel Nagar','Delhi','FabHotel Galaxy, 7/2, West Patel Nagar, New Delhi, Delhi 110008',3,'Good',2140,13.9,7.5,9,'2019-08-07','2019-08-18','fabGalaxy1'),('FabHotel Gandharva','Pune','FabHotel Gandharva,1291,1292, Off J.M.Road, Shivajinagar,thorat colony, 411005, Pune.',4,'Good',3590,10.30,3.80,8,'2019-08-06','2019-08-20','fab_gandharva2'),('FabHotel Namaste BnB','Delhi','FabHotel Namaste BnB 13A, Palam Marg, Vasant Vihar Opp. Mata Malai Mandir Behind KAS Medical Centre, 110057, Delhi, India',3,'Good',3220,13.4,13.8,9,'2019-08-07','2019-08-17','namste1'),('FabHotel Prime President','Pune','FabHotel Prime President,34/11, Prabhat Road, Lane No-8, Off Karve Road, 411004, Pune.',3,'Average',2570,12.40,6.00,8,'2019-08-06','2019-08-15','fab_prime5'),('FabHotel Prime Sage Saket','Delhi','FabHotel Prime Sage Saket Plot No. 4, Navjeevan Vihar, Malviya Nagar, 110017, Delhi, India',3,'Good',4189,17.4,13.9,9,'2019-08-05','2019-08-15','fabGalaxy4'),('FabHotel Rajwada','Pune','FabHotel Rajwada Ward No. 8, Someshwarwadi, Pashan, 411045, Pune.',3,'Average',2575,14.70,9.20,9,'2019-08-06','2019-08-18','fab_rajwada4'),('Hotel Bawa International','Mumbai','Hotel Bawa international, Nehru Road , 400 099, Mumbai, India',3,'Excellent',5320,1,20.5,16,'2019-08-05','2019-08-15','bawa2'),('Hotel Spree Shivai','Pune','Hotel Spree - Shivai, Plot no A-70, H Block, MIDC Pimpri, 411018, Pune.',5,'Excellent',6135,20.00,17.00,8,'2019-08-08','2019-08-15','fab_spree2'),('Hotel The Orchid','Mumbai','Hotel The Orchid, 70 C, Nehru Road, Villa Parle East, 400099, Mumbai, India',4,'Excellent',7670,1,20.5,9,'2019-08-04','2019-08-15','orchid2'),('Hyatt Pune','Pune','Hyatt Pune, 88 Nagar Road, Kalyani Nagar, 411006, Pune.',5,'Excellent',6269,3.10,6.30,7,'2019-08-08','2019-08-18','Hyatt-Pune5'),('The Empresa','Mumbai','The Empresa SAB TV LANE, OPP LAXMI PLAZA,, 400053, Mumbai, India',4,'Excellent',7079,7.8,25.1,8,'2019-08-05','2019-08-05','empresa3'),('The Royal Plaza','Delhi','Royal Plaza Hotel, 19, Ashoka Rd, Janpath, Connaught Place, New Delhi 110001',4,'Good',6950,20.2,3,7,'2019-08-05','2019-08-15','royal1'),('Treebo Trend Basera','Pune','Treebo Basera 690/1, Bajirao Road, Near Prabhat Theatre, 411002, Pune.',4,'Good',2570,11.50,4.20,7,'2019-08-08','2019-08-20','treebo_basera4'),('Treebo Trend Brooks Elan','Pune','Treebo Trend Brooks Elan 232/1-2, Plot No.- 40, Sakore Nagar, 411014, Pune.',3,'Average',2533,1.90,7.90,6,'2019-08-05','2019-08-20','treebo_brooks5');
/*!40000 ALTER TABLE `booking_com` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-08-02 23:44:05
