-- MySQL dump 10.13  Distrib 8.0.12, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: dbpune
-- ------------------------------------------------------
-- Server version	8.0.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fabhotels`
--

DROP TABLE IF EXISTS `fabhotels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `fabhotels` (
  `hotel_name` varchar(45) NOT NULL,
  `city` varchar(45) NOT NULL,
  `address` varchar(255) NOT NULL,
  `star` int(11) NOT NULL,
  `rating` varchar(45) DEFAULT NULL,
  `price` double NOT NULL,
  `dist_airport` double NOT NULL,
  `dist_stat` double NOT NULL,
  `rooms` int(11) DEFAULT NULL,
  `checkIn` varchar(50) DEFAULT NULL,
  `chechOut` varchar(50) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`hotel_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fabhotels`
--

LOCK TABLES `fabhotels` WRITE;
/*!40000 ALTER TABLE `fabhotels` DISABLE KEYS */;
INSERT INTO `fabhotels` VALUES ('FabExpress Gateway Inn Andheri East','Mumbai','FabExpress Gateway Inn Andheri East, Gala no 7A, Chimat Pada, opp Ruby Compound, Moral Naka, 400059, Mumbai, India',3,'Good',4350,3,27,8,'2019-08-05','2019-08-17','gateway3'),('FabExpress Karishma','Pune','FabExpress Karishma 318, Rasta Peth, Near K.E.M. Hospital, 411011, Pune.',3,'Good',1556,9.7,2.3,7,'2019-08-02','2019-08-11','fab_karishma2'),('FabExpress Konark Inn Ghansoli','Mumbai','FabExpress Konark Inn Ghansoli ,Sector Number 4 Road, Plot No 351/352, 400701, Mumbai, India',3,'Average',1860,25,32,9,'2019-08-05','2019-08-15','Konark3'),('FabHotel Alpine Tree','Delhi','FabHotel Alpine Tree, A-65, National Highway - 08, Near IGI Airport, Mahipalpur, New Delhi 110037',3,'Good',1844,7.8,16.1,6,'2019-08-02','2019-08-15','fabAlpine3'),('FabHotel Galaxy Patel nagar','Delhi','FabHotel Galaxy, 7/2, West Patel Nagar, New Delhi, Delhi 110008',3,'Average',1784,19.9,7.5,7,'2019-08-04','2019-08-13','fabGalaxy2'),('FabHotel Gandharva','Pune','FabHotel Gandharva,1291,1292, Off J.M.Road, Shivajinagar,thorat colony, 411005, Pune.',4,'Excellent',3694,10.3,3.8,6,'2019-08-03','2019-08-11','fab_gandharva2'),('FabHotel Namaste BnB','Delhi','FabHotel Namaste BnB 13A, Palam Marg, Vasant Vihar Opp. Mata Malai Mandir Behind KAS Medical Centre, 110057, Delhi, India',3,'Excellent',3040,13.8,13.8,8,'2019-08-05','2019-08-11','namste4'),('FabHotel Prime Presiden','Pune','FabHotel Prime President,34/11, Prabhat Road, Lane No-8, Off Karve Road, 411004, Pune.',3,'Good',2350,12.4,6,8,'2019-08-03','2019-08-10','fabGalaxy4'),('FabHotel Prime Sage Saket','Delhi','FabHotel Prime Sage Saket Plot No. 4, Navjeevan Vihar, Malviya Nagar, 110017, Delhi, India',3,'Good',3945,13.9,13.9,12,'2019-08-02','2019-08-12','royal5'),('FabHotel Rajwada','Pune','FabHotel Rajwada Ward No. 8, Someshwarwadi, Pashan, 411045, Pune.',3,'Average',2385,14.7,9.2,9,'2019-08-05','2019-08-14','royal1'),('FabHotel Stay Inn','Pune','FabHotel Stay Inn, Mangal Murti Estate, Wakad, 411057, Pune.',3,'Average',1680,25.5,19.9,7,'2019-08-07','2019-08-18','royal4');
/*!40000 ALTER TABLE `fabhotels` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-08-03 11:47:24
