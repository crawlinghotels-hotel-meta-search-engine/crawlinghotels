package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.pojo.booking_com;
import com.example.demo.pojo.fabhotels;

public interface booking_comRepository extends JpaRepository<booking_com,String>  {

	@Query("SELECT b FROM booking_com b WHERE b.city = :city")
    public List<booking_com> findByCity(@Param("city") String city);
    
    @Query("SELECT b FROM booking_com b WHERE b.city = :city and b.rating=:rating")
    public List<booking_com> findByRating(@Param("city") String city,@Param("rating") String rating);
    
    @Query("SELECT b FROM booking_com b WHERE b.city = :city and b.stars=:stars")
    public List<booking_com> findByStars(@Param("city") String city,@Param("stars") int stars);
}
