package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.pojo.expedia;
import com.example.demo.pojo.fabhotels;

public interface fabhotelsRepository extends JpaRepository<fabhotels,String> {

}
