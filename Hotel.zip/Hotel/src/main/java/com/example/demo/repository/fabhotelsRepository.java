package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.pojo.booking_com;
import com.example.demo.pojo.fabhotels;

public interface fabhotelsRepository extends JpaRepository<fabhotels,String> {

	
	@Query("SELECT f FROM fabhotels f WHERE f.city = :city")
    public List<fabhotels> findByCity(@Param("city") String city);
    
    @Query("SELECT f FROM fabhotels f WHERE f.city = :city and f.rating=:rating")
    public List<fabhotels> findByRating(@Param("city") String city,@Param("rating") String rating);
    
    @Query("SELECT f FROM fabhotels f WHERE f.city = :city and f.stars=:stars")
    public List<fabhotels> findByStars(@Param("city") String city,@Param("stars") int stars);
}
