package com.example.demo.pojo;

import java.time.LocalDate;
import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="fabhotels")
public class fabhotels {
	


	private String hotelname;
	private String rating;
	private String address;
	private String image;
	private double dist_airport;
	private double dist_station;
	private double price;
	private int stars;
	private String city;
	private LocalDate checkIn,checkOut;
	private int rooms;
	
	

	public fabhotels() {
		super();
	}



	public fabhotels(String hotelname, String rating, String address, String image, double dist_airport,
			double dist_station, double price, int stars, String city, LocalDate checkIn, LocalDate checkOut,
			int rooms) {
		super();
		this.hotelname = hotelname;
		this.rating = rating;
		this.address = address;
		this.image = image;
		this.dist_airport = dist_airport;
		this.dist_station = dist_station;
		this.price = price;
		this.stars = stars;
		this.city = city;
		this.checkIn = checkIn;
		this.checkOut = checkOut;
		this.rooms = rooms;
	}


  @Id
  @Column(name="hotel_name")
	public String getHotelname() {
		return hotelname;
	}



	public void setHotelname(String hotelname) {
		this.hotelname = hotelname;
	}


	@Column(name="rating")
	public String getRating() {
		return rating;
	}



	public void setRating(String rating) {
		this.rating = rating;
	}


	@Column(name="address")
	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}


	@Column(name="image")
	public String getImage() {
		return image;
	}



	public void setImage(String image) {
		this.image = image;
	}


	@Column(name="dist_airport")
	public double getDist_airport() {
		return dist_airport;
	}



	public void setDist_airport(double dist_airport) {
		this.dist_airport = dist_airport;
	}


	@Column(name="dist_stat")
	public double getDist_station() {
		return dist_station;
	}



	public void setDist_station(double dist_station) {
		this.dist_station = dist_station;
	}


	@Column(name="price")
	public double getPrice() {
		return price;
	}



	public void setPrice(double price) {
		this.price = price;
	}


	@Column(name="star")
	public int getStars() {
		return stars;
	}



	public void setStars(int stars) {
		this.stars = stars;
	}


	@Column(name="city")
	public String getCity() {
		return city;
	}



	public void setCity(String city) {
		this.city = city;
	}


	@Column(name="checkIn")
	public LocalDate getCheckIn() {
		return checkIn;
	}



	public void setCheckIn(LocalDate checkIn) {
		this.checkIn = checkIn;
	}


	@Column(name="checkOut")
	public LocalDate getCheckOut() {
		return checkOut;
	}



	public void setCheckOut(LocalDate checkOut) {
		this.checkOut = checkOut;
	}


	@Column(name="rooms")
	public int getRooms() {
		return rooms;
	}



	public void setRooms(int rooms) {
		this.rooms = rooms;
	}



	
	
	


}
