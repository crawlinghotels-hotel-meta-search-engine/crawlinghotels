package com.example.demo.pojo;

import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class fabhotels {
	

	private String hotelname;
	
	private int rating;
	
	private String address;
	
	private byte[] image;
	
	private  String dist_airport;
	
	private  String dist_station;
	
	private double price;
	
	

	public fabhotels() {
		super();
	}



	public fabhotels(String hotelname, int rating, String address, byte[] image,  String dist_airport,  String dist_station,
			double price) {
		super();
		this.hotelname = hotelname;
		this.rating = rating;
		this.address = address;
		this.image = image;
		this.dist_airport = dist_airport;
		this.dist_station = dist_station;
		this.price = price;
	}


  @Id
  @Column(name="hotel_name")
	public String getHotelname() {
		return hotelname;
	}



	public void setHotelname(String hotelname) {
		this.hotelname = hotelname;
	}


	@Column(name="rating")
	public int getRating() {
		return rating;
	}



	public void setRating(int rating) {
		this.rating = rating;
	}

	@Column(name="address")
	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}


	@Column(name="image")
	public byte[] getImage() {
		return image;
	}



	public void setImage(byte[] image) {
		this.image = image;
	}


	@Column(name="d.a")
	public  String getDist_airport() {
		return dist_airport;
	}



	public void setDist_airport( String dist_airport) {
		this.dist_airport = dist_airport;
	}


	@Column(name="d.s")
	public  String getDist_station() {
		return dist_station;
	}



	public void setDist_station( String dist_station) {
		this.dist_station = dist_station;
	}


	@Column(name="price")
	public double getPrice() {
		return price;
	}



	public void setPrice(double price) {
		this.price = price;
	}
	
	


}
