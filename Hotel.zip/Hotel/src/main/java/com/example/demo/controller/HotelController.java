package com.example.demo.controller;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.example.demo.pojo.booking_com;
import com.example.demo.pojo.expedia;
import com.example.demo.pojo.fabhotels;
import com.example.demo.repository.booking_comRepository;
import com.example.demo.repository.expediaRepository;
import com.example.demo.repository.fabhotelsRepository;

import com.example.demo.pojo.Hotel;


@CrossOrigin(origins="http://localhost:4200",allowedHeaders ="*" )
@RestController

public class HotelController  {
	
	
	
	@Autowired
	private expediaRepository expediar;
	@Autowired
	private booking_comRepository bookingr;
	@Autowired
	private fabhotelsRepository fabr;
	
	
	@GetMapping("/all/{city}")
	public HashSet<Hotel> getAllHotels(@PathVariable String city)
	{
	List<expedia> exp=expediar.findByCity(city);
	List<fabhotels> fb=fabr.findByCity(city);
	List<booking_com> book=bookingr.findByCity(city);
	
	Hotel hotel=new Hotel();
	HashSet<Hotel> hs=hotel.getAll(exp, book, fb);
	return hs;
	}
	
	
	@GetMapping("/all/{city}/prices")
	public LinkedHashSet<Hotel> getSortHotels(@PathVariable String city)
	{
	
		List<expedia> exp=expediar.findByCity(city);
		List<fabhotels> fb=fabr.findByCity(city);
		List<booking_com> book=bookingr.findByCity(city);
		
	Hotel hotel_class=new Hotel();
	return hotel_class.getByPrice(exp, book, fb);
	
	
	}
	@GetMapping("/all/{city}/distair")
	public LinkedHashSet<Hotel> getSortDistAir(@PathVariable String city)
	{
	
		List<expedia> exp=expediar.findByCity(city);
		List<fabhotels> fb=fabr.findByCity(city);
		List<booking_com> book=bookingr.findByCity(city);
		
	Hotel hotel_class=new Hotel();
	return hotel_class.getByDistAir(exp, book, fb);
	
	
	}
	
	@GetMapping("/all/{city}/diststat")
	public LinkedHashSet<Hotel> getSortDistStat(@PathVariable String city)
	{
	
		List<expedia> exp=expediar.findByCity(city);
		List<fabhotels> fb=fabr.findByCity(city);
		List<booking_com> book=bookingr.findByCity(city);
		
	Hotel hotel_class=new Hotel();
	return hotel_class.getByDistStat(exp, book, fb);
	
	
	}
	
	
	@GetMapping("/all/{city}/rating/{rate}")
	public LinkedHashSet<Hotel> getRating(@PathVariable String city,@PathVariable String rate)
	{


		List<expedia> exp=expediar.findByRating(city, rate);
		List<fabhotels> fb=fabr.findByRating(city, rate);
		List<booking_com> book=bookingr.findByRating(city, rate);
		
		Hotel hotel_class=new Hotel();
		return hotel_class.getByRating(exp, book, fb);
	}
	
	
	@GetMapping("/all/{city}/stars/{stars}")
	public LinkedHashSet<Hotel> getStars(@PathVariable String city,@PathVariable int stars)
	{
		List<expedia> exp=expediar.findByStars(city, stars);
		List<fabhotels> fb=fabr.findByStars(city, stars);
		List<booking_com> book=bookingr.findByStars(city, stars);
		
		
		Hotel hotel_class=new Hotel();
		return hotel_class.getByStars(exp, book, fb);
	}
	
	
	

	
	
	

}
