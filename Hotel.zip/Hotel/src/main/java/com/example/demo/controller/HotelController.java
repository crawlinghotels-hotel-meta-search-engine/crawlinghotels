package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.pojo.Hotel;
import com.example.demo.pojo.booking_com;
import com.example.demo.pojo.expedia;
import com.example.demo.pojo.fabhotels;
import com.example.demo.repository.booking_comRepository;
import com.example.demo.repository.expediaRepository;
import com.example.demo.repository.fabhotelsRepository;




@RestController
//@RequestMapping("/expedia")
public class HotelController  {
	
	
	
	@Autowired
	private expediaRepository expediar;
	@Autowired
	private booking_comRepository bookingr;
	@Autowired
	private fabhotelsRepository fabr;
	
	
	
	@GetMapping("/hello")
	public List<Object> getAllHotels()
	{
		System.out.println("awais");
	List<Object> lobj=new ArrayList<Object>();
	lobj.add(expediar.findAll());
	lobj.add(bookingr.findAll());	
	lobj.add(fabr.findAll());
		return lobj;	
	}
	
	
	@GetMapping("/price")
	public List<Object> getSortHotels()
	{
		System.out.println("awais");
	List<Object> lobj=new ArrayList<Object>();
	List<expedia> exp=expediar.findAll(org.springframework.data.domain.Sort.by("price"));
	List<booking_com> book=bookingr.findAll(org.springframework.data.domain.Sort.by("price"));	
	List<fabhotels> fb=fabr.findAll(org.springframework.data.domain.Sort.by("price"));
	
	Hotel<expedia, booking_com, fabhotels> h=new Hotel(exp,book,fb);
	h.getByPrices();
	
		return lobj;
	}
	
	
	@GetMapping("/prices")
	public TreeSet<Object> getPrice()
	{
		List<Object> ol=new ArrayList<Object>();
		ol.add(expediar.findAll());
		ol.add(bookingr.findAll());
		ol.add(fabr.findAll());
		TreeSet<Object> ts=new TreeSet<Object>();
		ts.add(ol);
		return ts;
	}
	
//	@GetMapping("/heya")
//	public a
	
	
	
	
	
	
	

}
