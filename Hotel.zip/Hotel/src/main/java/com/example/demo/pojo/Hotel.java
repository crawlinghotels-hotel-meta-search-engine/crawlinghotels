package com.example.demo.pojo;
import com.example.demo.pojo.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.TreeSet;

public class Hotel{
	private String hotelname;
	private String rating;
	private String address;
	private String image;
	private double dist_airport;
	private double dist_station;
	private double price;
	private int stars;
	private String city;
	private LocalDate checkIn,checkOut;
	private int rooms;
	private String classname;
	
	
	public Hotel() {
		super();
	}

	
	public Hotel(String hotelname, String rating, String address, String image, double dist_airport,
			double dist_station, double price, int stars, String city, LocalDate checkIn, LocalDate checkOut,
			int rooms,String classname) {
		super();
		this.hotelname = hotelname;
		this.rating = rating;
		this.address = address;
		this.image = image;
		this.dist_airport = dist_airport;
		this.dist_station = dist_station;
		this.price = price;
		this.stars = stars;
		this.city = city;
		this.checkIn = checkIn;
		this.checkOut = checkOut;
		this.rooms = rooms;
		this.classname=classname;
	}

	

	public String getClassname() {
		return classname;
	}


	public void setClassname(String classname) {
		this.classname = classname;
	}


	public String getHotelname() {
		return hotelname;
	}


	public void setHotelname(String hotelname) {
		this.hotelname = hotelname;
	}


	public String getRating() {
		return rating;
	}


	public void setRating(String rating) {
		this.rating = rating;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getImage() {
		return image;
	}


	public void setImage(String image) {
		this.image = image;
	}


	public double getDist_airport() {
		return dist_airport;
	}


	public void setDist_airport(double dist_airport) {
		this.dist_airport = dist_airport;
	}


	public double getDist_station() {
		return dist_station;
	}


	public void setDist_station(double dist_station) {
		this.dist_station = dist_station;
	}


	public double getPrice() {
		return price;
	}


	public void setPrice(double price) {
		this.price = price;
	}


	public int getStars() {
		return stars;
	}


	public void setStars(int stars) {
		this.stars = stars;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public LocalDate getCheckIn() {
		return checkIn;
	}


	public void setCheckIn(LocalDate checkIn) {
		this.checkIn = checkIn;
	}


	public LocalDate getCheckOut() {
		return checkOut;
	}


	public void setCheckOut(LocalDate checkOut) {
		this.checkOut = checkOut;
	}


	public int getRooms() {
		return rooms;
	}


	public void setRooms(int rooms) {
		this.rooms = rooms;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((hotelname == null) ? 0 : hotelname.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {  
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Hotel other = (Hotel) obj;
		if (hotelname == null) {
			if (other.hotelname != null)
				return false;
		} else if (!hotelname.equals(other.hotelname))
			return false;
		return true;
	}
	
	public List<Hotel> getList(List<expedia> exp ,List<booking_com> book,List<fabhotels> fb)

	{
		List<Hotel> hotel_list=new ArrayList<Hotel>();
		
		
		
		for(expedia e1:exp)
		{
			Hotel h=new Hotel(e1.getHotelname(),e1.getRating(),e1.getAddress(),e1.getImage(),e1.getDist_station(),
					e1.getDist_airport(),e1.getPrice(),e1.getStars(),e1.getCity(),e1.getCheckIn(),e1.getCheckOut(),e1.getRooms(),(e1.getClass().getName()).substring(22));
			hotel_list.add(h);
			
		}
		for(booking_com b1:book)
		{
			Hotel h=new Hotel(b1.getHotelname(),b1.getRating(),b1.getAddress(),b1.getImage(),b1.getDist_station(),b1.getDist_airport(),
					b1.getPrice(),b1.getStars(),b1.getCity(),b1.getCheckIn(),b1.getCheckOut(),b1.getRooms(),(b1.getClass().getName()).substring(22));
			hotel_list.add(h);
			
		}
		
		for(fabhotels f1:fb)
		{
			Hotel h=new Hotel(f1.getHotelname(),f1.getRating(),f1.getAddress(),f1.getImage(),f1.getDist_airport(),f1.getDist_station(),
					f1.getPrice(),f1.getStars(),f1.getCity(),f1.getCheckIn(),f1.getCheckOut(),f1.getRooms(),(f1.getClass().getName()).substring(22));
			hotel_list.add(h);
			
		}
		
		return hotel_list;
		
		
	}
	public  LinkedHashSet<Hotel> getByPrice(List<expedia> exp ,List<booking_com> book,List<fabhotels> fb)   //------------------------ Sorting By price
	{
		List<Hotel> hotel_list=new ArrayList<Hotel>();
		 LinkedHashSet<Hotel> hs=new  LinkedHashSet<Hotel>();
		 
		hotel_list=getList(exp,book,fb);
		
		Collections.sort(hotel_list, new Comparator<Hotel>() {
			public int compare(Hotel h1,Hotel h2)
			{
				return ((Double)h1.getPrice()).compareTo(h2.getPrice());
			}
			
		});
		
		hs.addAll(hotel_list);
		
		return hs;
 	}
	
	public HashSet<Hotel> getAll(List<expedia> exp ,List<booking_com> book,List<fabhotels> fb)  //------------------------------------Getting All w.r.t city
	{
		List<Hotel> hotel_list=new ArrayList<Hotel>();
		HashSet<Hotel> hash=new HashSet<Hotel>();
		
		hotel_list=getList(exp,book,fb);
		
		hash.addAll(hotel_list);
		return hash;
	}
	
	public LinkedHashSet<Hotel> getByRating(List<expedia> exp ,List<booking_com> book,List<fabhotels> fb)
	{
		List<Hotel> hotel_list=new ArrayList<Hotel>();
		 LinkedHashSet<Hotel> hs=new  LinkedHashSet<Hotel>();
		 
		hotel_list=getList(exp,book,fb);
		
		Collections.sort(hotel_list, new Comparator<Hotel>() {
			public int compare(Hotel h1,Hotel h2)
			{
				return ((String)h2.getRating()).compareTo(h1.getRating());
			}
			
		});
		
		hs.addAll(hotel_list);
		
		return hs;
	}
	
	public LinkedHashSet<Hotel> getByStars(List<expedia> exp ,List<booking_com> book,List<fabhotels> fb)
	{
		List<Hotel> hotel_list=new ArrayList<Hotel>();
		 LinkedHashSet<Hotel> hs=new  LinkedHashSet<Hotel>();
		 
		hotel_list=getList(exp,book,fb);
		
		Collections.sort(hotel_list, new Comparator<Hotel>() {
			public int compare(Hotel h1,Hotel h2)
			{
				return ((Integer)h2.getStars()).compareTo(h1.getStars());
			}
			
		});
		
		hs.addAll(hotel_list);
		
		return hs;
	}
	public LinkedHashSet<Hotel> getByDistAir(List<expedia> exp ,List<booking_com> book,List<fabhotels> fb)
	{
		List<Hotel> hotel_list=new ArrayList<Hotel>();
		 LinkedHashSet<Hotel> hs=new  LinkedHashSet<Hotel>();
		 
		hotel_list=getList(exp,book,fb);
		
		Collections.sort(hotel_list, new Comparator<Hotel>() {
			public int compare(Hotel h1,Hotel h2)
			{
				return ((Double)h1.getDist_airport()).compareTo(h2.getDist_airport());
			}
			
		});
		
		hs.addAll(hotel_list);
		
		return hs;
	}
	
	public LinkedHashSet<Hotel> getByDistStat(List<expedia> exp ,List<booking_com> book,List<fabhotels> fb)
	{
		List<Hotel> hotel_list=new ArrayList<Hotel>();
		 LinkedHashSet<Hotel> hs=new  LinkedHashSet<Hotel>();
		 
		hotel_list=getList(exp,book,fb);
		
		Collections.sort(hotel_list, new Comparator<Hotel>() {
			public int compare(Hotel h1,Hotel h2)
			{
				return ((Double)h1.getDist_station()).compareTo(h2.getDist_station());
			}
			
		});
		
		hs.addAll(hotel_list);
		
		return hs;
	}
}

