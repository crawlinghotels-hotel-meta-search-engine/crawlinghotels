package com.example.demo.pojo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import javax.persistence.Entity;

public class Hotel<T,u,v> {
	T obj1;
	u obj2;
	v obj3;
	public Hotel(T obj1, u obj2, v obj3) {
		super();
		this.obj1 = obj1;
		this.obj2 = obj2;
		this.obj3 = obj3;
	}
	public T getObj1() {
		return obj1;
	}
	public void setObj1(T obj1) {
		this.obj1 = obj1;
	}
	public u getObj2() {
		return obj2;
	}
	public void setObj2(u obj2) {
		this.obj2 = obj2;
	}
	public v getObj3() {
		return obj3;
	}
	public void setObj3(v obj3) {
		this.obj3 = obj3;
	}
	
	public void getByPrices()
	{
		List<T> t=new ArrayList<T>();
		
		Collections.sort(t ,new Comparator<T>()
		{
			public int compare(T t1,T t2)
			{
				return t1.getObj1().getPrice().compareTo(t2.getObj1().getPrice());
			}
		});
 		
		List<Object> list=new ArrayList<Object>();
		
		
	}
	
		
	
	
	
	
}
