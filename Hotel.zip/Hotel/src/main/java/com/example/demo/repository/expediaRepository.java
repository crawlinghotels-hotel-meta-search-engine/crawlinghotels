package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.pojo.expedia;
import com.example.demo.pojo.fabhotels;

public interface expediaRepository extends JpaRepository<expedia,String> {

	@Query("SELECT e FROM expedia e WHERE e.city = :city")
    public List<expedia> findByCity(@Param("city") String city);
    
    @Query("SELECT e FROM expedia e WHERE e.city = :city and e.rating=:rating")
    public List<expedia> findByRating(@Param("city") String city,@Param("rating") String rating);
    
    @Query("SELECT e FROM expedia e WHERE e.city = :city and e.stars=:stars")
    public List<expedia> findByStars(@Param("city") String city,@Param("stars") int stars);
}
