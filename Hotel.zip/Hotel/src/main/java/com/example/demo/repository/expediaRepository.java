package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.pojo.expedia;

public interface expediaRepository extends JpaRepository<expedia,String> {

}
