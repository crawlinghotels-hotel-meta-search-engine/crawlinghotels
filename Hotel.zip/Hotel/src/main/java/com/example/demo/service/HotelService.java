//package com.example.demo.service;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import javax.transaction.Transactional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.example.demo.pojo.expedia;
//import com.example.demo.repository.booking_comRepository;
//import com.example.demo.repository.expediaRepository;
//import com.example.demo.repository.fabhotelsRepository;
//
//
//@Service
//@Transactional
//public class HotelService {
//
//	@Autowired
//	private expediaRepository expediar;
//	@Autowired
//	private booking_comRepository bookingr;
//	@Autowired
//	private fabhotelsRepository fabr;
//	
//	
//	
//	
//	
//	public List<expedia> getAllHotels()
//	{
//	// List<expedia> ex=new ArrayList<expedia>();
//		List<expedia> l=expediar.findAll();
//		
//		return l;
//	}
//	
//	
//	
//	
//	
//	
//	
//}
